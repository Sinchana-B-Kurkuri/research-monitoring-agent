# Corrected report source

Open main.tex as the main document in Overleaf, or compile with Tectonic:

    tectonic main.tex

For pdfLaTeX, run pdflatex, bibtex, then pdflatex twice.

The supplied PDF was compiled using Tectonic 0.17.0 and visually reviewed on all 12 pages.
Formatting repairs include column-safe multi-line equations, breakable code identifiers,
a wrapped configuration table, and keeping the final prompt within one column.
The author and contact details match the supplied PDF. All original report wording,
mathematical expressions, table entries, bibliography data, and figure files are retained.
The only additional report content is the requested GitHub link in Code Availability.
No factual or implementation-alignment revisions were made in this formatting pass.

Validation: zero overfull boxes, missing characters, or undefined references;
text remains within page margins; GitHub link verified as a clickable PDF annotation.
